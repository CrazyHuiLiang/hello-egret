# Egret Engine 5.2.13 Release Notes


---


Egret Engine was officially released on May 25, 2018 5.2 stable version. On October 29, 2018, we will release a stable version of 5.2.13. This version has added support for baidugame.


## 2D Rendering - JavaScript

* Fixed the issue of setting the fill mode invalidation when eai.Image is set to open the native display list

## baidugame

* Added baidugame support