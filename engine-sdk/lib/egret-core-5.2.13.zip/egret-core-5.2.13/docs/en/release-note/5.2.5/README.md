# Egret Engine 5.2.5 Release Notes


---


Egret Engine was officially released on May 25, 2018 5.2 stable version. On July 16, 2018, we will release a stable version of 5.2.5. This release is a centralized bug fix for version 5.2


## 2D Rendering - JavaScript

* Fix filter and cacheAsBitmap to cancel filter rendering bugs at the same time
* Fix text measurement error in micro-end environment
* Fix Bezier curve measurement width and height inaccuracy

## Command Line

* Optimize commonjs mode compilation warning prompt