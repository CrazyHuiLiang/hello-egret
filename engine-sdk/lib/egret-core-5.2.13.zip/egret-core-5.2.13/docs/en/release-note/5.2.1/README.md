# Egret Engine 5.2.1 Release Notes


---


Egret Engine was officially released on May 25, 2018 5.2 stable version. On June 4, 2018, we will release a stable version of 5.2.1. This release is a centralized bug fix for version 5.2



## 2D Rendering - JavaScript

* Fixed an issue with rendering exceptions when filters and irregular masks were nested

## WeChat Games Support Library

Wechat mini-game support library Please update your project with a WeChat mini-game via Egret Launcher. Version number 1.1.1

* Supports local file caching
* Fixed an issue where the audio file played abnormally from the specified location