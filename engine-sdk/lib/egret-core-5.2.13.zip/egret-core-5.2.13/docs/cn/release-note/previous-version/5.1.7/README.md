# 白鹭引擎 5.1.7 发布日志


---


白鹭引擎在 2017年 12 月份正式发布了 5.1 版本。在 2018年3月15日，我们将发布 5.1.7 版本。本次版本是 5.1 版本的一次功能更新和集中性缺陷修复，主要目标是添加 Facebook Instant Games SDK 支持。



## 2D 渲染 - JavaScript 

* 新增 Facebook Instant Games SDK
* 修复 GlowFilter 在 iOS 设备上显示异常问题
* 修复 scale 为 0 的情况下测量异常问题（感谢开发者 zyy）
* 修复 ColorMatrixFilter 在特定情况下渲染异常问题（感谢开发者 zyy）

## AssetsManager
* 修复使用 getResByUrl 加载字体异常问题（感谢开发者 43714946）

## 第三方库
* 修复鼠标库 MOUSE_MOVE 事件派发异常问题（感谢开发者 zyy）


